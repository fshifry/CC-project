<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewpoint" content="width=device-width,initial-scale=1">
    <title> Registeration to the customer</title>


    <script src="Js/jquery.min.js" type="text/javascript"></script>
    <script src="Js/popper.min.js" type="text/javascript"></script>

</head>

<body>

    <div class="container">

        <h1>
            <center>Register Account</center>
        </h1>
        <!--Register to the customer-->


        <form id="customer_registration">

            <div class="row">

                <div class="col-25">
                    <label><b>Name</label></b>
                </div>

                <div class="col-75">
                    <input type="text" placeholder="Enter your Full name" name="name" required>
                </div>
            </div>

            <div class="row">

                <div class="col-25">
                    <label><b>Address</label></b>
                </div>

                <div class="col-75">
                    <input type="text" placeholder="Enter your House Address" name="address" required>
                </div>
            </div>

            <div class="row">

                <div class="col-25">
                    <label><b>Contact No</label></b>
                </div>

                <div class="col-75">
                    <input type="tel" placeholder="Enter your Phone Number" name="phone" required>
                </div>
            </div>

            <div class="row">

                <div class="col-25">
                    <label><b>E-mail</label></b>
                </div>

                <div class="col-75">
                    <input type="email" placeholder="Enter your Email Address" name="email" required>
                </div>
            </div>

            <div class="row">

                <div class="col-25">
                    <label><b>Password</label></b>
                </div>

                <div class="col-75">
                    <input type="password" placeholder="Enter your password" id="password" name="password" required>
                </div>

                <div class="row">

                    <div class="col-25">
                        <label><b>Confirm Password</label></b>
                    </div>

                    <div class="col-75">
                        <input type="password" placeholder="Enter the same password" id="comfirm_password" name="cpassword" required>
                    </div>

                    <div class="row">
                        <input type="submit" value="Next">
                    </div>

                </div>
            </div>
        </form>
    </div>
</body>

<script type="text/javascript">
$(document).ready(function(e) {

        $("#customer_registration").on('submit', (function(e) {

                if ($('#comfirm_password').val() == $('#password').val()) {

                    e.preventDefault();

                    $.ajax({

                        url: "Controllers/customerRegistration.php",
                        type: "POST",
                        data: new FormData(this),
                        contentType: false,
                        cache: false,
                        processData: false,
                        success: function(data) {

                            alert(data);

                        }

                    });

                } else {

                    alert("Passwords are not matched");

                }

            })

        );

    }

);
</script>

</html>