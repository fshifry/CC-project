<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="urf-8">
    <meta name="viewpoint" content="width=device-width,initial-scale=1">
    <Title>Log in</Title>

    <script src="Js/jquery.min.js" type="text/javascript"></script>
    <script src="Js/popper.min.js" type="text/javascript"></script>
</head>

<body>

    <div class="col-md-6" align="right">
        <form class="d-flex">
            <button class="btn btn-outline-success" type="submit"><a href="#">Customer Dashboard</button></a>
        </form>
    </div>

    <h1>
        <center>Login</center>
    </h1>


    <div class="login">
        <form id="login">
            <label><b>Email</b></label>
            <input type="email" name="Ename" id="Ename" placeholder="" required>
            <br><br>

            <label><b>Password</b></label>
            <input type="Password" name="Pass" id="Pass" placeholder="" required>
            <br><br>

            <a href="Register_customer.php"><b> Don't have an account</a></b>
            <br><br>

            <input type="submit" name="signin" id="signin" value="Sign in">

        </form>
    </div>

</body>

<script>
$(document).ready(function(e) {

    $("#login").on('submit', (function(e) {

        e.preventDefault();

        $.ajax({

            url: "Controllers/customerLogin.php",
            type: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                alert(data);
            }

        });

    }));

});
</script>

</html>