<?php

    session_start();

    if(isset($_SESSION['resturentRegMessage'])){

        echo '<script>alert("'.$_SESSION['resturentRegMessage'].'");</script>';

        session_destroy();

    }

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="urf-8">
    <meta name="viewpoint" content="width=device-width,initial-scale=1">
    <title>Registeration to the restaurant</title>
    <script src="Js/jquery.min.js" type="text/javascript"></script>
    <script src="Js/popper.min.js" type="text/javascript"></script>
</head>

<body>

    <div class="container">

        <h1>
            <center>Register Resturant</center>
        </h1>
        <!--Register to the customer-->


        <form id="customer_registration">

            <div class="row">

                <div class="col-25">
                    <label><b>Name</label></b>
                </div>

                <div class="col-75">
                    <input type="text" placeholder="Enter your restaurant name" name="name" required>
                </div>
            </div>

            <div class="row">

                <div class="col-25">
                    <label><b>Email</label></b>
                </div>

                <div class="col-75">
                    <input type="email" placeholder="Enter your email Address" name="email" required>
                </div>
            </div>

            <div class="row">

                <div class="col-25">
                    <label><b>Address</label></b>
                </div>

                <div class="col-75">
                    <input type="text" placeholder="Enter your Address" name="address" required>
                </div>
            </div>

            <div class="row">

                <div class="col-25">
                    <label><b>Phone Number</label></b>
                </div>

                <div class="col-75">
                    <input type="tel" placeholder="Enter your phone number" name="phone" required>
                </div>
            </div>

            <div class="row">

                <div class="col-25">
                    <label><b>Password</label></b>
                </div>

                <div class="col-75">
                    <input type="password" placeholder="Enter your password" id="password" name="password" required>
                </div>

                <div class="row">

                    <div class="col-25">
                        <label><b>Confirm Password</label></b>
                    </div>

                    <div class="col-75">
                        <input type="password" placeholder="Enter the same password" id="comfirm_password" name="cpassword" required>
                    </div>

                    <div class="row">
                        <input type="submit" value="Submit">
                    </div>

                </div>
            </div>
        </form>
    </div>
</body>

<script type="text/javascript">
$(document).ready(function(e) {

    $("#resturent_register").on('submit', (function(e) {

        if ($("#cpassword").val() == $("#password").val()) {

            e.preventDefault();

            $.ajax({

                url: "Controllers/resturentRegistration.php",
                type: "POST",
                data: new FormData(this),
                contentType: false,
                cache: false,
                processData: false,
                success: function(data) {

                    Console.log("Hiiiiiiii");
                    alert("Data : " + data);

                },
                error: function(data) {

                    alert("hii");

                }

            });

        } else {
            alert('Passwords are not matching');
        }

    }));

});
</script>


</html>