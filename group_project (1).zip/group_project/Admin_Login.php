<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="urf-8">
    <meta name="viewpoint" content="width=device-width,initial-scale=1">
    <title>Administration Login</title>

    <script src="Js/jquery.min.js" type="text/javascript"></script>
    <script src="Js/popper.min.js">
    type = "text/javascript" >
    </script>

</head>

<body>

    <div class="col-md-6" align="right">
        <form class="d-flex">
            <button class="btn btn-outline-success" type="submit"><a href="#">Admin Dashboard</button></a>
        </form>
    </div>

    <h1>
        <center>Login</center>
    </h1>

    <div class="login">
        <form id="login">
            <label><b>Email</b></label>
            <input type="email" name="Ename" id="Ename" placeholder="">
            <br><br>

            <label><b>Password</b></label>
            <input type="password" name="pass" id="Pname" placeholder="">
            <br><br>

            <br><br>
            <input type="submit" name="signin" id="signin" value="Sign in">


        </form>
    </div>
</body>

<script>
$(document).ready(function(e) {

    $("#login").on('submit', (function(e) {

        e.preventDefault();

        $.ajax({

            url: "Controllers/adminLogin.php",
            type: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                alert(data);
            }

        });

    }));

});
</script>

</html>